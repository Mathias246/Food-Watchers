﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using foodTracker.Data;
using foodTracker.Models;

namespace foodTracker.Controllers
{
    public class FoodEatensController : Controller
    {
        private readonly ApplicationDbContext _context;

        public FoodEatensController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: FoodEatens
        public async Task<IActionResult> Index()
        {
            return View(await _context.FoodEaten.ToListAsync());
        }

        // GET: FoodEatens/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var foodEaten = await _context.FoodEaten
                .FirstOrDefaultAsync(m => m.UserId == id);
            if (foodEaten == null)
            {
                return NotFound();
            }

            return View(foodEaten);
        }

        // GET: FoodEatens/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: FoodEatens/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("UserId,FoodName,Calories")] FoodEaten foodEaten)
        {
            if (ModelState.IsValid)
            {
                _context.Add(foodEaten);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(foodEaten);
        }

        // GET: FoodEatens/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var foodEaten = await _context.FoodEaten.FindAsync(id);
            if (foodEaten == null)
            {
                return NotFound();
            }
            return View(foodEaten);
        }

        // POST: FoodEatens/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, [Bind("UserId,FoodName,Calories")] FoodEaten foodEaten)
        {
            if (id != foodEaten.UserId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(foodEaten);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FoodEatenExists(foodEaten.UserId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(foodEaten);
        }

        // GET: FoodEatens/Delete/5
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var foodEaten = await _context.FoodEaten
                .FirstOrDefaultAsync(m => m.UserId == id);
            if (foodEaten == null)
            {
                return NotFound();
            }

            return View(foodEaten);
        }

        // POST: FoodEatens/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var foodEaten = await _context.FoodEaten.FindAsync(id);
            _context.FoodEaten.Remove(foodEaten);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool FoodEatenExists(string id)
        {
            return _context.FoodEaten.Any(e => e.UserId == id);
        }
    }
}
