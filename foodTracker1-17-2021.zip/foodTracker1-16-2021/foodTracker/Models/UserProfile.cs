﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace foodTracker.Models
{
    public partial class UserProfile
    {
        [Key]
        public string UserId { get; set; }
        public string UserName { get; set; }
        public double? StartWeigth { get; set; }
        public double? CurrentWeigth { get; set; }
        public double? DesiredWeigth { get; set; }
        public int? HeigthF { get; set; }
        public int? HeightI { get; set; }
        public string Gender { get; set; }
        public string Activity { get; set; }
        public DateTime? Birthday { get; set; }
        public int? Calories { get; set; }
    }
}
