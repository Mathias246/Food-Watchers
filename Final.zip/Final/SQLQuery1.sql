create table userProfile(
userID varchar not null primary key,
userName varchar(50) not null,
startWeigth float,
currentWeigth float,
desiredWeigth float,
heigth float,
gender varchar(20) not null,
activity varchar(50),
birthday date,
Age int,
calories int
)

create table foodEaten(
userID varchar not null primary key,
foodName varchar,
calories int
)