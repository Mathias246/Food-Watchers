﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace foodTracker.Migrations
{
    public partial class foodTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
