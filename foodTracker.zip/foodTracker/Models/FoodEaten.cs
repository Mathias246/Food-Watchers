﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace foodTracker.Models
{
    public class FoodEaten
    {
        [Key]
        public string UserId { get; set; }
        public string FoodName { get; set; }
        public int Calories { get; set; }
    }
}
