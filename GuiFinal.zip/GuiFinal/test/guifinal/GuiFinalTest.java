/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guifinal;

import org.junit.Test;
import static org.junit.Assert.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Time;
import org.junit.After;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


/**
 *
 * @author Jeremy
 */
public class GuiFinalTest {
    
    public GuiFinalTest() {
    }
    WebDriver driver;
    URL page;

    @Before
    public void setup() {
        System.setProperty("webdriver.chrome.driver", "c:\\!Selenium\\chromedriver.exe");
        driver = new ChromeDriver();
        try {
            page = new URL("https://localhost:44380/");
        } catch (MalformedURLException ex) {
            System.out.println("Error 404 - URL bad");
            System.exit(404);
        }
    }

    @After
    public void tearDown() {
       driver.quit();
    }

    //unit tests
    @Test
    public void testnavbarappearsonpage(){
        driver.get(page.toString());
        WebElement nav = driver.findElement(By.xpath("/html/body/header/nav/div/div/ul[2]"));
        
        String test = nav.getText();
        assertTrue(test.contains(nav.getText()));
    }
    
    @Test
    public void testchartappears(){
        driver.get(page.toString());
        WebElement myChart = driver.findElement(By.id("myChart"));
        
        String test = myChart.getText();
        assertTrue(test.contains(myChart.getText()));
    }
    
    @Test
    public void tableappears(){
        driver.get(page.toString());
        WebElement databaseLink = driver.findElement(By.xpath("/html/body/header/nav/div/div/ul[2]/li[2]/a"));
        databaseLink.click();
        
        WebElement table = driver.findElement(By.xpath("/html/body/div[1]/main/table"));
        String test = table.getText();
        assertTrue(test.contains(table.getText()));
    }
    
    @Test
    public void footerappears(){
        driver.get(page.toString());
        WebElement footer = driver.findElement(By.xpath("/html/body/footer"));
        
        String test = footer.getText();
        assertTrue(test.contains(footer.getText()));
    }
    
    @Test
    public void imgappearsinnav(){
        driver.get(page.toString());
        WebElement img = driver.findElement(By.xpath("/html/body/header/nav/div/img"));
        String test = img.getText();
        assertTrue(test.contains(img.getText()));
    }
    
    @Test
    public void foodinputboxesappear(){
        driver.get(page.toString());
        WebElement foodname = driver.findElement(By.id("FoodName"));
        WebElement calories = driver.findElement(By.id("Calories"));
        
        String test = foodname.getText();
        assertTrue(test.contains(foodname.getText()));
        String test2 = foodname.getText();
        assertTrue(test2.contains(calories.getText()));
        
        
    }
    
    //functional tests
    @Test
    public void testuserlogin() {
        driver.get(page.toString());
        
        WebElement loginlink = driver.findElement(By.xpath("/html/body/header/nav/div/div/ul[1]/li[2]/a"));
        loginlink.click();
        
        WebElement email = driver.findElement(By.id("Input_Email"));
        email.sendKeys("yeet@yeet.com");
        
        WebElement password = driver.findElement(By.id("Input_Password"));
        password.sendKeys("Yeet#123");
        
        WebElement submit = driver.findElement(By.id("login-submit"));
        submit.click();
          
    }
    
    @Test
    public void testuserreg() {
        driver.get(page.toString());
        
        WebElement reglink = driver.findElement(By.xpath("/html/body/header/nav/div/div/ul[1]/li[1]/a"));
        reglink.click();
        
        WebElement email = driver.findElement(By.id("Input_Email"));
        email.sendKeys("sawtoothkiller@gmail.com");
        
        WebElement password = driver.findElement(By.id("Input_Password"));
        password.sendKeys("HorizonZero#543");
        
        WebElement confpassword = driver.findElement(By.id("Input_ConfirmPassword"));
        confpassword.sendKeys("HorizonZero#543");
        
        WebElement submit = driver.findElement(By.id("registerSubmit"));
        submit.click();
        
        
    }
    
    @Test
    public void testgototable() {
        driver.get(page.toString());
        
        WebElement databaseLink = driver.findElement(By.xpath("/html/body/header/nav/div/div/ul[2]/li[2]/a"));
        databaseLink.click();
        
        
        
    }
    
    @Test
    public void testinputfood() throws InterruptedException{
        driver.get(page.toString());
        WebElement loginlink = driver.findElement(By.xpath("/html/body/header/nav/div/div/ul[1]/li[2]/a"));
        loginlink.click();
        
        WebElement email = driver.findElement(By.id("Input_Email"));
        email.sendKeys("yeet@yeet.com");
        
        WebElement password = driver.findElement(By.id("Input_Password"));
        password.sendKeys("Yeet#123");
        
        WebElement submit = driver.findElement(By.id("login-submit"));
        submit.click();
        
        WebElement foodname = driver.findElement(By.id("FoodName"));
        foodname.sendKeys("Chicken");
         
        WebElement calories = driver.findElement(By.id("Calories"));
        calories.sendKeys("100");
        
        WebElement databaseLink = driver.findElement(By.xpath("/html/body/header/nav/div/div/ul[2]/li[2]/a"));
        databaseLink.click();
        Thread.sleep(10);
        
        
    }
    
    @Test
    public void testdeletefoodItem(){
        driver.get(page.toString());
        
        WebElement databaseLink = driver.findElement(By.xpath("/html/body/header/nav/div/div/ul[2]/li[2]/a"));
        databaseLink.click();
        
        WebElement delete = driver.findElement(By.xpath("/html/body/div[1]/main/table/tbody/tr[5]/td[3]/a[3]"));
        delete.click();
        
        WebElement fullDelete = driver.findElement(By.xpath("/html/body/div[1]/main/div/form/input[2]"));
        fullDelete.click();
    }
    
    @Test
    public void testeditfoodItem(){
        driver.get(page.toString());
        
        WebElement loginlink = driver.findElement(By.xpath("/html/body/header/nav/div/div/ul[1]/li[2]/a"));
        loginlink.click();
        
        WebElement email = driver.findElement(By.id("Input_Email"));
        email.sendKeys("yeet@yeet.com");
        
        WebElement password = driver.findElement(By.id("Input_Password"));
        password.sendKeys("Yeet#123");
        
        WebElement submit = driver.findElement(By.id("login-submit"));
        submit.click();
        
        WebElement foodname = driver.findElement(By.id("FoodName"));
        foodname.sendKeys("Cookie");
         
        WebElement calories = driver.findElement(By.id("Calories"));
        calories.sendKeys("500");
        
        WebElement foodsubmit = driver.findElement(By.xpath("/html/body/div[1]/main/div/div/form/div[4]/input"));
        foodsubmit.click();
        
        WebElement databaseLink = driver.findElement(By.xpath("/html/body/header/nav/div/div/ul[2]/li[2]/a"));
        databaseLink.click();
        
        WebElement Edit = driver.findElement(By.xpath("/html/body/div[1]/main/table/tbody/tr[5]/td[3]/a[1]"));
        Edit.click();
        
        
    }
    
}
